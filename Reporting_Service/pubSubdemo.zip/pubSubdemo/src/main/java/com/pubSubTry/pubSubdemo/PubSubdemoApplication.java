package com.pubSubTry.pubSubdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PubSubdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PubSubdemoApplication.class, args);
	}

}
